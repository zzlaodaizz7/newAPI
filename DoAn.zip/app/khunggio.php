<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class khunggio extends Model
{
    //
    protected $table = "khunggio";

    protected $fillable=[ 'id', 'thoigian'];
}
